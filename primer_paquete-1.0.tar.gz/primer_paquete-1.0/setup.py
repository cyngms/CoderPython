from setuptools import setup

setup(
    name="primer_paquete",
    version="1.0",
    description="",
    author="Luis",
    author_email="luis@gmail.com",
    packages=["calculadora"]
)