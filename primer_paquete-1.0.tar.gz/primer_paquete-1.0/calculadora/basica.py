def suma(*args):
    resultado = 0
    for val in args:
        resultado += val
    return resultado

def multiplicar(*args):
    resultado = 0
    return resultado


def dividir(num1, num2):
    return num1 / num2


